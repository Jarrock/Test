#include <iostream>
#include<intToFloatProj.h>

int main()
{
	int i = intToFloat::ChangeToInt(80.96);
	int dec = intToFloat::GetDecimals(1.89652, 3);
	float f = intToFloat::ChangeToFloat(1, dec, 2);
	std::cout << "Changing 80.96 to an integer:\n" << i << "\n\n";
	std::cout << "Getting the decimals of 1.89652, with 3 sig figs:\n" << dec << "\n\n";
	std::cout << "Changing the whole number 1 and the decimal number 896\nto a float with 2 sig figs:\n" << f << "\n\n";
	system("pause");
	return 0;
}