#ifndef INTTOFLOAT
#define INTTOFLOAT
#include<cmath>
#include<math.h>

static class intToFloat
{
public:
	//Converts a float to an integer
	static int ChangeToInt(float num);
	//Gets a number of decimals equal to the numbe of significant figures
	static int GetDecimals(float num, int sigFigs);
	//Converts an integer number and decimal point number to a float, with sigFigs number of significant figures
	static float ChangeToFloat(int num, int decimals, int sigFigs);
};


#endif INTTOFLOAT